package Veterinaria.example.demo.Controller;

import Veterinaria.example.demo.Entity.Client;
import Veterinaria.example.demo.Service.ClientService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping
public class ClientController {
    @Autowired
    private ClientService clientService;
@GetMapping("/{getclientid}")
    public Client getClientById(@PathVariable("getclientid")final int clientId){
    Client client = clientService.getClientById(clientId);
    return client;
    }
    @PostMapping
    @RequestMapping (value = "CreateClient", method = RequestMethod.POST)
    public ResponseEntity<?> CreateClient(@RequestBody Client client){
        Client clientCreate = clientService.createClient(client);
        return  ResponseEntity.status(HttpStatus.CREATED).body(clientCreate);
    }
    @PutMapping("/{clientId}")
    public ResponseEntity<Client> updateClientById(@RequestBody Client client, @PathVariable("clienteId")final int clientId){
    clientService.updateClient(client, clientId);
    return  ResponseEntity.ok().build();
    }

    @DeleteMapping("/client/{id}")
    public void deleteClient(@PathVariable int id){
    clientService.getClientById(id);
    }
}
