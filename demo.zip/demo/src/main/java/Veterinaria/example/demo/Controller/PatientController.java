package Veterinaria.example.demo.Controller;

import Veterinaria.example.demo.Entity.Patient;
import Veterinaria.example.demo.Service.PatientService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping
public class PatientController {
    @Autowired
    private PatientService patientService;
    @GetMapping("/{getpatientid}")
    public Patient getPatientById(@PathVariable("getpatientid")final int patientId){
        Patient patient = patientService.getPatientById(patientId);
        return patient;
    }
    @PostMapping
    @RequestMapping (value = "CreatePatient", method = RequestMethod.POST)
    public ResponseEntity<?> CreatePatient(@RequestBody Patient patient){
        Patient patientCreate = patientService.createPatient(patient);
        return  ResponseEntity.status(HttpStatus.CREATED).body(patientCreate);
    }
    @PutMapping("/{patientId}")
    public ResponseEntity<Patient> updatePatientById(@RequestBody Patient patient, @PathVariable("patientId")final int patientId){
        patientService.updatePatient(patient, patientId);
        return  ResponseEntity.ok().build();
    }

    @DeleteMapping("/patient/{id}")
    public void deletePatient(@PathVariable int id){
        patientService.getPatientById(id);
    }
}
