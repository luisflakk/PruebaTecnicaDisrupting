package Veterinaria.example.demo.Service;

import Veterinaria.example.demo.Entity.Client;
import Veterinaria.example.demo.Entity.Doctor;
import Veterinaria.example.demo.Repository.ClientRepository;
import Veterinaria.example.demo.Repository.DoctorRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class DoctorService {
    @Autowired
    private DoctorRepository doctorRepository;
    public Doctor getDoctorById(final  int id) {
        Doctor doctor = doctorRepository.findById(id).get();
        return  doctor;
    }
    public Doctor createDoctor(final Doctor doctor){
        doctorRepository.save(doctor);
        return  doctor;
    }
    public Doctor updateDoctor(final Doctor doctor, final  int id){
        final Doctor doctor1 = doctorRepository.findById(id).get();
        doctorRepository.save(doctor1);
        return  doctor1;
    }

    public void deleteDctor (final int id){
        doctorRepository.deleteById(id);
    }
}
