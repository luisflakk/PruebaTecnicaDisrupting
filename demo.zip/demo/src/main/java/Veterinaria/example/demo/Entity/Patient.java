package Veterinaria.example.demo.Entity;

import jakarta.persistence.*;
import lombok.AccessLevel;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.format.annotation.DateTimeFormat;

import java.util.Date;

@Entity
@Data
@Table(name ="pacient")
@NoArgsConstructor(access = AccessLevel.PROTECTED)
public class Patient {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private int id;
    @Column(name = "pacient_name")
    private String pacient_name;
    @Column(name = "birthday")
    @DateTimeFormat(pattern = "dd/mm/yyyy")
    private Date birthday;
    @Column(name = "client_name")
    private String client_name;

}
