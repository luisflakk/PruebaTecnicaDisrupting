package Veterinaria.example.demo.Controller;

import Veterinaria.example.demo.Entity.Doctor;
import Veterinaria.example.demo.Service.DoctorService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping
public class DoctorController {
    @Autowired
    private DoctorService doctorService;
    @GetMapping("/{getdoctorid}")
    public Doctor getDoctorById(@PathVariable("getdoctorid")final int doctorId){
        Doctor doctor = doctorService.getDoctorById(doctorId);
        return doctor;
    }
    @PostMapping
    @RequestMapping (value = "CreateDoctor", method = RequestMethod.POST)
    public ResponseEntity<?> CreateDoctor(@RequestBody Doctor doctor){
        Doctor doctorCreate = doctorService.createDoctor(doctor);
        return  ResponseEntity.status(HttpStatus.CREATED).body(doctorCreate);
    }
    @PutMapping("/{doctorId}")
    public ResponseEntity<Doctor> updateDoctorById(@RequestBody Doctor doctor, @PathVariable("doctorId")final int doctorId){
        doctorService.updateDoctor(doctor, doctorId);
        return  ResponseEntity.ok().build();
    }

    @DeleteMapping("/doctor/{id}")
    public void deleteDoctor(@PathVariable int id){
        doctorService.getDoctorById(id);
    }
}
