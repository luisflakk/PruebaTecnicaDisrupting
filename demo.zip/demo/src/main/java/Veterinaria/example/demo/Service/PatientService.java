package Veterinaria.example.demo.Service;

import Veterinaria.example.demo.Entity.Patient;
import Veterinaria.example.demo.Repository.PatientRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class PatientService {
    @Autowired
    private PatientRepository patientRepository;
    public Patient getPatientById(final  int id) {
        Patient patient = patientRepository.findById(id).get();
        return  patient;
    }
    public Patient createPatient(final Patient patient){
        patientRepository.save(patient);
        return  patient;
    }
    public Patient updatePatient(final Patient patient, final  int id){
        final Patient patient1 = patientRepository.findById(id).get();
        patientRepository.save(patient1);
        return  patient1;
    }

    public void deletePatient (final int id){
        patientRepository.deleteById(id);
    }
}
