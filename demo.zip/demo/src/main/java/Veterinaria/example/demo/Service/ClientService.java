package Veterinaria.example.demo.Service;

import Veterinaria.example.demo.Entity.Client;
import Veterinaria.example.demo.Repository.ClientRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class ClientService {
    @Autowired
    private ClientRepository clientRepository;
    public Client getClientById(final  int id) {
        Client client = clientRepository.findById(id).get();
        return  client;
    }
    public Client createClient(final Client client){
        clientRepository.save(client);
        return  client;
    }
    public Client updateClient(final Client client, final  int id){
        final Client client1 = clientRepository.findById(id).get();
        clientRepository.save(client1);
        return  client1;
    }

    public void deleteClient (final int id){
        clientRepository.deleteById(id);
    }
}
